Harmless test archive used to verify attachment metadata handling.
